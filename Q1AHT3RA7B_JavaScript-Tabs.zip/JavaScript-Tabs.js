let abT = document.getElementById("aboutTab");
let timT = document.getElementById("timeToVisitTab");
let attT = document.getElementById("attractionsTab");
let btA = document.getElementById("aboutButton");
let btT = document.getElementById("timeToVisitButton");
let btAtt = document.getElementById("attractionsButton");

function About() {
    abT.classList.remove("d-none");
    timT.classList.add("d-none");
    attT.classList.add("d-none");

    btA.classList.add("selected-button");
    btT.classList.remove("selected-button");
    btAtt.classList.remove("selected-button");
}

function Time() {
    abT.classList.add("d-none");
    timT.classList.remove("d-none");
    attT.classList.add("d-none");

    btA.classList.remove("selected-button");
    btT.classList.add("selected-button");
    btAtt.classList.remove("selected-button");
}

function Att() {
    abT.classList.add("d-none");
    timT.classList.add("d-none");
    attT.classList.remove("d-none");

    btA.classList.remove("selected-button");
    btT.classList.remove("selected-button");
    btAtt.classList.add("selected-button");
}